import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageComponent } from './components/landing-page/landing-page.component';
import { InflablesComponent } from './components/inflables/inflables.component';

const routes: Routes = [
  { path: "", component: LandingPageComponent, pathMatch: "full" },
  { path: "infables", component: InflablesComponent, pathMatch: "full" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
